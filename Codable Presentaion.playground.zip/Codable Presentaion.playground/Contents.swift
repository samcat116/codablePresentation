import UIKit

//URL Endpoint
let urlEndpoint = URL(string: "https://api.spacexdata.com/v3/cores/B1042?pretty=true")!


//Getting the Raw JSON with JSONSerialization
let task = URLSession.shared.dataTask(with: urlEndpoint) { data, response, error in
	
	if error != nil {
		return
	}
	
	
	if let data = data {
		guard let jsonString = String(data: data, encoding: .utf8) else {
			return
		}
		print(jsonString)
		do{
			let json = try JSONSerialization.jsonObject(with: data) as! [String: Any]
			if let serial = json["core_serial"] {
				print("The serial for this core is : \(serial)")
			}
			
		} catch {
			print("There was an error converting the JSON")
			return
		}
		
	}
}
task.resume()














//Part 2: Using Codable

//Mission Struct
struct Mission: Codable {
	let name: String
	let flight: Int
}

//Rocket Core Struct
struct Core: Codable {
	let core_serial: String
	let block: Int
	let status: String
	let original_launch: String
	let original_launch_unix: Int
	let missions: [Mission]
	let reuse_count: Int
	let rtls_attempts: Int
	let rtls_landings: Int
	let asds_attempts: Int
	let asds_landings: Int
	let water_landing: Bool
	let details: String
}


let task2 = URLSession.shared.dataTask(with: urlEndpoint) { data, response, error in
	if error != nil {
		return
	}
	
	if let data = data {
		let jsonDecoder = JSONDecoder()
		
		do {
			let core = try jsonDecoder.decode(Core.self, from: data)
			print(core.asds_landings)
			print(core.details)
		} catch {
			print("There was an error decoding the JSON")
			return
		}
	}
}
task2.resume()

















//Part 3: JSON Encoding using Codable
let newCore = Core(core_serial: "123113",
				   block: 3,
				   status: "retired",
				   original_launch: "2017-12-10:34:00.94Z",
				   original_launch_unix: 123324234235,
				   missions: [Mission(name: "BlahSat 5", flight: 34)],
				   reuse_count: 34,
				   rtls_attempts: 12,
				   rtls_landings: 33,
				   asds_attempts: 445,
				   asds_landings: 3,
				   water_landing: true,
				   details: "This is a fake core")

let encoder = JSONEncoder()
encoder.outputFormatting = .prettyPrinted
let newCoreJSON = try! encoder.encode(newCore)
let newCoreJSONString = String(data: newCoreJSON, encoding: .utf8)!
print(newCoreJSONString)


















//Part 4: Case Conversions

struct Core2: Codable {
	let coreSerial: String
	let block: Int
	let status: String
	let originalLaunch: String
	let originalLaunchUnix: Int
	let missions: [Mission]
	let reuseCount: Int
	let rtlsAttempts: Int
	let rtlsLandings: Int
	let asdsAttempts: Int
	let asdsLandings: Int
	let waterLanding: Bool
	let details: String
	
	
}


let task3 = URLSession.shared.dataTask(with: urlEndpoint) { data, response, error in
	if let data = data {
		let decoder2 = JSONDecoder()
		decoder2.keyDecodingStrategy = .convertFromSnakeCase
		let core = try! decoder2.decode(Core2.self, from: data)
		print(core.asdsLandings)
		print(core.details)
	}
}

task3.resume()



























//Part 5: Custom Encoding Keys

struct Core3: Codable {
	let number: String
	let block: Int
	let status: String
	let original_launch: String
	let original_launch_unix: Int
	let missions: [Mission]
	let reuse_count: Int
	let rtls_attempts: Int
	let rtls_landings: Int
	let asds_attempts: Int
	let asds_landings: Int
	let water_landing: Bool
	let details: String
	
	enum CodingKeys: String, CodingKey {
		case number = "core_serial"
		case block
		case status
		case original_launch
		case original_launch_unix
		case missions
		case reuse_count
		case rtls_attempts
		case rtls_landings
		case asds_attempts
		case asds_landings
		case water_landing
		case details
	}
}


let task4 = URLSession.shared.dataTask(with: urlEndpoint) { data, response, error in
	if let data = data {
		let decoder = JSONDecoder()
		let core = try! decoder.decode(Core3.self, from: data)
		print(core.number)
	}
}

task4.resume()



